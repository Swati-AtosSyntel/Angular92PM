import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularAppDay2';

  isSelected=true;
  show=true;

  colors=['Red','Green','Orange','Blue']
  day=1;
}
